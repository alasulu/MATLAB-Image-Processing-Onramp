ds = imageDatastore("testimages");
dataFilenames = ds.Files;
%You can use the numel function to find the total number of elements 
%in an array.
nFiles = numel(dataFilenames); %you can import all the images
img = read(ds);
imshow(img)