I = imread("receipt.jpeg");
gs = im2gray(I);
gs = imadjust(gs);
H = fspecial("average",3);
gs = imfilter(gs,H,"replicate");
BW = imbinarize(gs,"adaptive","ForegroundPolarity","dark");
figure
imshowpair(gs,BW,"montage")
%You can create a structuring element by using the strel function.
% "diamond" creates diamond shape structuring element and "disk" creates
% disk, second elements represent radius of structuring element
SE = strel("disk",8);
%To perform a closing operation on an image I with structuring element SE,
% use the imclose function.
Ibg = imclose(gs,SE);
figure
imshow(Ibg)
%In general, you can remove one image from another by subtracting it.
gsSub = Ibg-gs;
figure
imshow(gsSub)
BWsub = ~imbinarize(gsSub);
figure
imshow(BWsub)
%imbothat function does the every steps that we have done in the codes
%above closing an image, then subtracting the original image from the 
%closed image. It's known as the "bottom hat transform,"
BW_sum = sum(BW,2);
BWsub_sum = sum(BWsub,2);
figure
plot(BW_sum)
hold on
plot(BWsub_sum)
BW_end = imbothat(gs,SE); 
imshow(BW_end)