%To automate the threshold selection process, you can use the imbinarize 
% function, which calculates the "best" threshold for the image.
img = imread("receipt.jpeg");
gs = im2gray(img);
gsAdj = imadjust(gs);
figure
imshow(gsAdj)
%In imbinarize, you can designate whether the foreground is bright or 
% dark by setting the "ForegroundPolarity" option.
BW = imbinarize(gsAdj);
figure
imshow(BW)
BWadapt = imbinarize(gsAdj,"adaptive");
figure
imshowpair(gsAdj,BWadapt,"montage")
BWadapt = imbinarize(gsAdj,"adaptive","ForegroundPolarity","dark")
figure
imshowpair(gsAdj,BWadapt,"montage")