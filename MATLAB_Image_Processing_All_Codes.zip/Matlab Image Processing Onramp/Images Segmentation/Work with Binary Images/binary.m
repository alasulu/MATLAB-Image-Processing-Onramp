I = imread("recepit.jpeg");
gs = im2gray(I);
gsAdj = imadjust(gs);
BW = imbinarize(gsAdj,"adaptive","ForegroundPolarity","dark");
figure
imshowpair(I,BW,"montage")
I2 = imread("earth.jpeg");
gs2 = im2gray(I2);
gs2Adj = imadjust(gs2);
BW2 = imbinarize(gs2Adj);
figure
imshowpair(I2,BW2,"montage")
S = sum(BW,2); %2 represents dimension in this code,  sums across rows of 
% an array
figure
plot(S)
S2 = sum(BW2,2);
plot(S2)