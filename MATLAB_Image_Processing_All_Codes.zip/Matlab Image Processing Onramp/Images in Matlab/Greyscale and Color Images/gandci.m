A = imread("agu.jpeg"); %uint8 represents the 2^8 = 256 intensity level
%from 0 to 255
A_show = imshow(A)
sz= size(A);
R = A(:,:,1);
G = A(:,:,2);
B = A(:,:,3);
R_max = max(R,[],"all");
R_min = min(R,[],"all");
G_max = max(G,[],"all");
G_min = min(G,[],"all");
B_max = max(B,[],"all");
B_min = min(B,[],"all");
figure
R_show = imshow(R)
figure
G_show = imshow(G)
figure
B_show = imshow(B)
%or showing all images seperately, you can you imsplit code in one time
%then you can combine it in one image with montage code
[R,G,B]= imsplit(A);
figure
montage({R,G,B})