clear
clc
I = imread("eal.jpeg");
I2 = imread("lale.jpeg");
I_gray = im2gray(I);
I2_gray = im2gray(I2);
I_gray_hist = imhist(I_gray)
figure
histogram(I_gray_hist)
I2_gray_hist = imhist(I2_gray)
figure
histogram(I2_gray_hist)
%Darker pixels have shifted to lower bins, while brighter pixels have
%shifted to higher bins with the codes below
I_gray_adjusted = imadjust(I_gray);
I2_gray_adjusted = imadjust(I2_gray);
imshowpair(I_gray,I_gray_adjusted,"montage")
figure
imshowpair(I2_gray,I2_gray_adjusted,"montage")
figure
histogram(I2_gray_adjusted)
%imadjust works only for grayscale images unless you provide additional 
%inputs to the function
%You can, however, use the function imlocalbrighten to adjust the contrast
%of a color image.
I2_colored = imlocalbrighten(I2_gray_adjusted);
figure
imshow(I2_colored)