ds = imageDatastore("testimages");
I = readimage(ds,2);
figure
imshow(I)
nFiles = numel(ds.Files);
isReceipt = false(1,nFiles);
receiptFiles = ds.Files(isReceipt);
figure
montage(receiptFiles)
for k= 1:nFiles
I = readimage(ds,k);
isReceipt(k) = classifyImage(I);
end
if isReceipt == 1
    disp("This is a Receipt")
else
    disp("This is not a Receipt")
end
function isReceipt = classifyImage(I)
    % This function processes an image and
    % classifies the image as receipt or non-receipt
    
    % Processing
    gs = im2gray(I);
    gs = imadjust(gs);
    
    mask = fspecial("average",3);
    gsSmooth = imfilter(gs,mask,"replicate");
    
    SE = strel("disk",8);  
    Ibg = imclose(gsSmooth, SE);
    Ibgsub =  Ibg - gsSmooth;
    Ibw = ~imbinarize(Ibgsub);
    
    SE = strel("rectangle",[3 25]);
    stripes = imopen(Ibw, SE);
    
    signal = sum(stripes,2);  

    % Classification
    minIndices = islocalmin(signal,"MinProminence",70,"ProminenceWindow",25); 
    nMin = nnz(minIndices);
    isReceipt = nMin >= 9;
    imshow(I)
end