I = imread("agu.jpeg");
I_show = imshow(I)
sz_I = size(I);
gs = im2gray(I);
sz_gs = size(gs);
figure
gs_show = imshow(gs)
imwrite(gs,"agu_saved.jpeg");