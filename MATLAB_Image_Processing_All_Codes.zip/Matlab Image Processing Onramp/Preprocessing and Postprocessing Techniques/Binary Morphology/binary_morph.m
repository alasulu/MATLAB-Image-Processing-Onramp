clear
clc
I = imread("receipt.jpeg");
Ig = im2gray(I);
Ig = imadjust(Ig);
Ig_bin = imbinarize(Ig,"adaptive","ForegroundPolarity","dark");
H = fspecial("average",3);
gs = imfilter(Ig,H,"replicate");
SEdisk= strel("disk",8);
Ibg = imclose(gs,SEdisk);
gsSub = Ibg - gs;
BW = ~imbinarize(gsSub);
imshowpair(I,BW,"montage")
%You can create a rectangular structuring element using strel with a
%size array in the format [height width].
SE = strel("rectangle",[10 20]);
%Emphasize the dark text instead, so perform the opposite operation and
%open the image using imopen.
BWstripes = imopen(BW,SE);
figure
imshow(BWstripes)
%You can analyze whether the opening operation has improved the image 
%processing algorithm 
S = sum(BWstripes,2);
figure
plot(S)
%Compare before and after improvements with the following codes below
Sbw = sum(BW,2);
figure
plot(S)
hold on
plot(Sbw)
hold off
