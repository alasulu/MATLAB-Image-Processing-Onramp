clear
clc
I = imread("noisy.jpeg");
gs = im2gray(I);
gs = imadjust(gs);
BW = imbinarize(gs,"adaptive","ForegroundPolarity","dark");
figure
imshowpair(gs,BW,"montage")
H = fspecial("average",3); %fspecial function to create an n-by-n averaging 
%filter.
gssmooth = imfilter(gs,H); %You can apply a filter F to an image I by using
%the imfilter function.
BWsmooth = imbinarize(gssmooth,"adaptive","ForegroundPolarity","dark");
figure
imshow(BWsmooth)
%The reason is that the default setting of imfilter sets pixels outside 
%the image to zero.
gssmooth = imfilter(gs,H,"replicate");
%Instead of zeros, the "replicate" option uses pixel intensity values on 
%the image border for pixels outside the image.
BWsmooth = imbinarize(gssmooth,"adaptive","ForegroundPolarity","dark");
figure
imshow(BWsmooth)
bw_sum = sum(BW,2);
bw_smooth_sum = sum(BWsmooth,2);
figure
plot(bw_sum)
hold on
plot(bw_smooth_sum)
%The noise and distortion in plots are wiped out after the applying the
%filter