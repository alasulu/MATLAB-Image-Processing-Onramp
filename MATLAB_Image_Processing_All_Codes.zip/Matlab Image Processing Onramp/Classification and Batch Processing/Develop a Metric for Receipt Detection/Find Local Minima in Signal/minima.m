clear
clc
%%%% Ignore the part between percentage sign
I = imread("receipt.jpeg");
Ig = im2gray(I);
Ig = imadjust(Ig);
Ig_bin = imbinarize(Ig,"adaptive","ForegroundPolarity","dark");
H = fspecial("average",3);
gs = imfilter(Ig,H,"replicate");
SEdisk= strel("disk",8);
Ibg = imclose(gs,SEdisk);
gsSub = Ibg - gs;
BW = ~imbinarize(gsSub);
SE = strel("rectangle",[10 20]);
BWstripes = imopen(BW,SE);
S = sum(BWstripes,2);
Sbw = sum(BW,2);
%%%%
montage({I,BW,BWstripes}) %Show the All Images in 1 Code
minIndices = islocalmin(S,"MinProminence",70,"ProminenceWindow",25);
figure
plot(S,"SeriesIndex",6,"DisplayName","Input data")
hold on
scatter(find(minIndices),S(minIndices),"v","filled","SeriesIndex",3, ...
"DisplayName","Local minima")
%scatter(x,y) creates a scatter plot with circular markers at the 
%locations specified by the vectors x and y.
title("Number of extrema: " + nnz(minIndices))
hold off
legend
%N = nnz(X) returns the number of nonzero elements in matrix X. For
%instance
% A= 1 0 0 0
%    0 1 0 0
%    0 0 1 0
%    0 0 0 1
% N = nnz(A) = 4