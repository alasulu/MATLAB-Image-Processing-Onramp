%You can create a binary black-and-white image from a grayscale image by 
% thresholding its intensity values. Values below the cutoff are assigned 
% the value 0, while values above are assigned the value 1.
img = imread("receipt.jpeg");
gs = im2gray(img);
gsAdj = imadjust(gs);
figure
imshow(gsAdj)
BW = gsAdj > 255/2;
figure
imshow(BW)
figure
imhist(gsAdj)
BW = gsAdj > 200;
figure
imshow(BW)